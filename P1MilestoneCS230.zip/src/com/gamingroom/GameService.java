package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// FIXME: Add missing pieces to turn this class a singleton -done
	// Create the only instance of GameService
	// The Singleton pattern creates this "single_instance" that is protected from reinstantiation. It is essential
	// that there is not more than one instance of GameService. This global variable will be the only access point,
	// so that the program cannot make multiple GameServices, because the extras would be unnecessary and inaccessible
	private static GameService single_instance = null;
	//Empty constructor to prevent instantiation
	private GameService() {};
	
	// If there is no instance, then one is created
	public static GameService getInstance() {
		if (single_instance == null) {
			single_instance = new GameService();
		}
		return single_instance;
		
	}


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply return the existing instance - done
		// The Iterator pattern is used to standardize the way a data set is searched. It is useful for keeping the
		// data type obscure or when you don't know the data type. In this case, "games" can store an element in any
		// form without having to change how the elements are accessed.
		//For as many games as exist in the list, look at the name of that game(nextGame), then compare it to input(game) 
		
		// Place games list in the iterator
	    Iterator<Game> gamesItList = games.iterator();
	    // Search through iterator for name
	    while(gamesItList.hasNext()) {
	    	  if ((gamesItList.next()).getName() == name) {
	    		  return gamesItList.next();
	    	  }
	    	}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same id
		// if found, simply assign that instance to the local variable - done
		//Search through games list. If ID matches an existing game(nextGame), assign local instance to that game
		// Iterator reduces the original code needed here because it applies to any data type. This Iterator is
		// the same as the last on except for .getId() and id
		
		// Place games list in the iterator
	    Iterator<Game> gamesItList = games.iterator();
	    // Search through iterator for id
	    while(gamesItList.hasNext()) {
	    	  if ((gamesItList.next()).getId() == id) {
	    		  game = gamesItList.next();
	    	  }
	    	}		
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable
		//Search through games list. If name matches an existing game(nextGame), assign local instance to that game
		// The Iterator pattern is helpful here because it doesn't matter what type of data we are searching for when
		// using Iterator. The code is very similar to the last 2 uses of Iterator
		
		// Place games list in the iterator
	    Iterator<Game> gamesItList = games.iterator();
	    // Search through iterator for name
	    while(gamesItList.hasNext()) {
	    	  if ((gamesItList.next()).getName() == name) {
	    		  game = gamesItList.next();
	    	  }
	    	}		
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
